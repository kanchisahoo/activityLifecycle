package com.example.activitylifecycle

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.widget.Button
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import com.example.activitylifecycle.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val editText:EditText=findViewById(R.id.user_message)
       binding.button1.setOnClickListener {
        val intent = Intent(this, SecondActivity::class.java)
           val message =editText.text.toString()
           intent.putExtra("TEXTMESSAGE", message)
           startActivity(intent)
       }
        binding.button2.setOnClickListener {
           Toast.makeText(this@MainActivity,"Hey, Buddy!!",Toast.LENGTH_SHORT).show()

        }
        binding.button3.setOnClickListener {
            val popup = PopupMenu(this,binding.button3)
            popup.inflate(R.menu.popup)
            popup.setOnMenuItemClickListener {
                Toast.makeText(this, "Item: "+it.title,Toast.LENGTH_SHORT).show()
                true
            }
            popup.show()

        }
        binding.button4.setOnClickListener {
            finish()
    }
    }
}