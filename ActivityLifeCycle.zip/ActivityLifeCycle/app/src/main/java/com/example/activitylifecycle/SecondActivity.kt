package com.example.activitylifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        val message=intent.getStringExtra("TEXTMESSAGE")
        val textView:TextView=findViewById(R.id.display_message)
        textView.setText(message)
    }
}